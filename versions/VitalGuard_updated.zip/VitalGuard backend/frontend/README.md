# VitalGuard Frontend

A responsive, browser-native research console for the existing FastAPI backend. It uses HTML, CSS and JavaScript without a frontend build step or third-party chart dependency.

## Run locally

1. Start the backend from the `backend` folder using the project's existing instructions. The default backend address is `http://localhost:8000`.
2. Serve this `frontend` directory using a local static server. For example, from this directory:

   ```bash
   python -m http.server 5173
   ```

3. Open `http://localhost:5173`.

The API base defaults to `http://localhost:8000/api/v1`. To point the app at another backend, set `window.VITALGUARD_API_BASE` before `app.js` loads in `index.html`, for example:

```html
<script>window.VITALGUARD_API_BASE = 'https://your-backend.example.com/api/v1';</script>
<script src="app.js"></script>
```

The backend CORS allowlist currently includes `http://localhost:5173` and `http://localhost:3000`. Add your actual deployed frontend origin to the backend CORS configuration before deployment.

## Implemented workflows

- Health/config/scenario loading and backend status display.
- Simulation form wired to `POST /api/v1/simulate`.
- Signal analysis wired to `POST /api/v1/analyze`.
- CSV upload/validation wired to `POST /api/v1/upload/csv`.
- Backend-generated JSON, CSV, and summary reports wired to `POST /api/v1/report`.
- Example CSV download, local CSV export, responsive signal chart, and in-memory session activity.

## Important limitation

This frontend is for research and demonstration. It does not connect to physical sensors, persist patient records, or treat the backend's configured ranges as validated age-specific pediatric clinical reference standards.
